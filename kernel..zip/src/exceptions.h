#include "globals.h"
#include "isr.h"
#include <stdarg.h>


void divide_by_0_callback();
